import { CommonException } from './common.exception';

export class NotFoundException extends CommonException {}
