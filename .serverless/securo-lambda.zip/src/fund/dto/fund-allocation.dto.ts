import { FundDTO } from './fund.dto';

export class FundAllocationDto extends FundDTO {
  userInvestedBalance: number;
}
