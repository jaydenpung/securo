export class BalanceDto {
  userFund: number;
  userWallet: number;
  fundOverall: number;
}
